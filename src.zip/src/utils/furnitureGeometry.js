export * from "../furniture";
